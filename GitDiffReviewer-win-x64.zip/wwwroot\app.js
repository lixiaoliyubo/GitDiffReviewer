// B4：工具栏 + 变更列表 + 统计。不接 Monaco（B5）。
(() => {
  const $ = (id) => document.getElementById(id);
  let nextId = 1;
  const pending = new Map();
  let current = null;       // 当前 changeSet
  let baseline = null;
  let repos = [];
  let activeRepo = '';
  let filter = 'all';
  let searchQ = '';
  let monacoReady = true;   // 改用内置 diff 渲染，恒为 true
  let diffEditor = null;
  let inlineDiff = true;

  // ---- 消息层 ----
  function send(type, payload = {}) {
    return new Promise((resolve, reject) => {
      const id = 'r-' + nextId++;
      pending.set(id, { resolve, reject });
      window.chrome.webview.postMessage({ id, type, payload });
    });
  }

  window.chrome.webview.addEventListener('message', async (e) => {
    const msg = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
    if (msg.replyTo && pending.has(msg.replyTo)) {
      const { resolve, reject } = pending.get(msg.replyTo);
      pending.delete(msg.replyTo);
      if (msg.ok) resolve(msg.data);
      else { showError(msg.error); reject(new Error(msg.error?.message)); }
    } else if (msg.type === 'treeChanged') {
      await loadChanges();
      toast(`检测到工作区变化（${msg.data.count} 个文件）`);
    }
  });

  function showError(err) {
    const bar = $('error-bar');
    bar.textContent = err?.message || '出错了';
    bar.classList.remove('hidden');
  }
  function toast(text, ms = 2500) {
    const t = $('toast');
    t.textContent = text;
    t.classList.remove('hidden');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.add('hidden'), ms);
  }

  // ---- 渲染 ----
  function fmtDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const p = (n) => String(n).padStart(2, '0');
    return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  function renderToolbar() {
    const sel = $('repo-select');
    sel.innerHTML = '';
    if (!repos.length) {
      const opt = document.createElement('option');
      opt.textContent = '（未选择仓库）';
      opt.value = '';
      sel.appendChild(opt);
    }
    for (const r of repos) {
      const opt = document.createElement('option');
      opt.value = r.path;
      opt.textContent = r.name || r.path;
      if (r.path === activeRepo) opt.selected = true;
      sel.appendChild(opt);
    }

    if (baseline && current) {
      $('baseline-info').textContent = `工作区 vs HEAD @ ${current.targetShort}`;
    } else {
      $('baseline-info').textContent = activeRepo ? '工作区改动' : '';
    }

    if (current) {
      const n = current.entries.length;
      $('stats').textContent = `${n} · +${current.totalInsertions} −${current.totalDeletions}`;
    } else {
      $('stats').textContent = '';
    }

    $('warn-nff').classList.toggle('hidden', !current?.nonFastForward);
  }

  function visibleEntries() {
    if (!current) return [];
    let entries = current.entries;
    if (showAllFiles && allFiles.length) {
      // 把全量文件合并进来：已在改动集里的保留原 entry，其余构造未改动 entry
      const changedSet = new Set(current.entries.map((e) => e.path));
      const unchanged = allFiles
        .filter((p) => !changedSet.has(p))
        .map((p) => ({ path: p, status: 'unchanged', insertions: 0, deletions: 0, binary: false }));
      entries = [...current.entries, ...unchanged];
    }
    return entries.filter((e) => {
      if (filter !== 'all' && e.status !== filter) return false;
      if (searchQ && !e.path.toLowerCase().includes(searchQ.toLowerCase())) return false;
      return true;
    });
  }

  const GROUP_ORDER = ['modified', 'added', 'deleted', 'renamed', 'copied'];
  const GROUP_LABEL = { modified: '修改', added: '新增', deleted: '删除', renamed: '重命名', copied: '复制' };
  const expandedDirs = new Set();
  let lastSelectedPath = null;
  let viewMode = 'tree';   // 'tree' | 'flat'
  let showAllFiles = false; // false=只看改动, true=全部文件
  let allFiles = [];        // showAllFiles=true 时的全量文件列表
  let rightTab = 'diff';    // 'diff' | 'info'
  let lastEntry = null;     // 当前选中的 entry（含元信息）

  function buildTree(entries) {
    const root = { name: '', path: '', children: new Map(), entries: [] };
    for (const e of entries) {
      const parts = e.path.split('/');
      parts.pop();
      let node = root;
      let acc = '';
      for (const seg of parts) {
        acc = acc ? acc + '/' + seg : seg;
        if (!node.children.has(seg)) {
          node.children.set(seg, { name: seg, path: acc, children: new Map(), entries: [] });
        }
        node = node.children.get(seg);
      }
      node.entries.push(e);
    }
    return root;
  }

  function dirAggregate(dirNode) {
    let files = dirNode.entries.length, adds = 0, dels = 0;
    let hasModify = false;
    for (const e of dirNode.entries) {
      adds += e.insertions; dels += e.deletions;
      if (e.status === 'modified' || e.status === 'deleted' || e.status === 'renamed') hasModify = true;
    }
    for (const child of dirNode.children.values()) {
      const a = dirAggregate(child);
      files += a.files; adds += a.adds; dels += a.dels;
      if (a.hasModify) hasModify = true;
    }
    return { files, adds, dels, hasModify };
  }

  function renderList() {
    const list = $('list');
    list.innerHTML = '';
    const entries = visibleEntries();

    const hasRepo = !!activeRepo;
    $('no-repo').classList.toggle('hidden', hasRepo);
    $('empty').classList.toggle('hidden', !hasRepo || entries.length > 0);

    if (!hasRepo || entries.length === 0) return;

    if (viewMode === 'flat') {
      const sorted = [...entries].sort((a, b) => a.path.localeCompare(b.path));
      for (const e of sorted) list.appendChild(fileRow(e, 0));
      return;
    }

    const root = buildTree(entries);
    function autoExpand(node) {
      const agg = dirAggregate(node);
      if (agg.files > 0 && agg.files <= 20) expandedDirs.add(node.path);
      for (const child of node.children.values()) autoExpand(child);
    }
    autoExpand(root);
    if (lastSelectedPath) {
      const parts = lastSelectedPath.split('/');
      let acc = '';
      for (let i = 0; i < parts.length - 1; i++) {
        acc = acc ? acc + '/' + parts[i] : parts[i];
        expandedDirs.add(acc);
      }
    }
    renderNode(list, root, 0);
  }

  function renderNode(container, node, depth) {
    const children = [...node.children.values()].sort((a, b) => a.name.localeCompare(b.name));
    for (const child of children) {
      const agg = dirAggregate(child);
      const expanded = expandedDirs.has(child.path);
      const dirRow = document.createElement('div');
      dirRow.className = 'tree-dir';
      dirRow.style.paddingLeft = (8 + depth * 14) + 'px';
      const iconCls = agg.hasModify ? 'dir-icon red' : 'dir-icon green';
      dirRow.innerHTML =
        '<span class="chevron">' + (expanded ? '▼' : '▶') + '</span>' +
        '<span class="' + iconCls + '"></span>' +
        '<span class="dir-name"></span>' +
        '<span class="dir-count"></span>';
      dirRow.querySelector('.dir-name').textContent = child.name;
      dirRow.querySelector('.dir-count').textContent = agg.files;
      dirRow.addEventListener('click', () => {
        if (expandedDirs.has(child.path)) expandedDirs.delete(child.path);
        else expandedDirs.add(child.path);
        renderList();
      });
      container.appendChild(dirRow);
      if (expanded) renderNode(container, child, depth + 1);
    }
    const files = [...node.entries].sort((a, b) => a.path.localeCompare(b.path));
    for (const e of files) container.appendChild(fileRow(e, depth));
  }

  function fileRow(e, depth) {
    const div = document.createElement('div');
    const isUnchanged = e.status === 'unchanged';
    div.className = 'row' + (e.path === lastSelectedPath ? ' selected' : '') + (isUnchanged ? ' unchanged' : '');
    div.dataset.path = e.path;
    div.style.paddingLeft = (8 + depth * 14 + 16) + 'px';

    const dot = document.createElement('span');
    if (isUnchanged) {
      dot.className = 'dot plain';
    } else {
      const cls = { added: 'A', modified: 'M', deleted: 'D', renamed: 'R', copied: 'R' }[e.status] || 'A';
      dot.className = 'dot ' + cls;
    }
    div.appendChild(dot);

    const path = document.createElement('span');
    path.className = 'path';
    const parts = e.path.split('/');
    const fname = parts.pop();
    path.innerHTML = '<span class="fname"></span>';
    path.querySelector('.fname').textContent = fname + (e.oldPath ? ' ← ' + e.oldPath : '');
    div.appendChild(path);

    const num = document.createElement('span');
    num.className = 'num';
    if (!isUnchanged) num.textContent = e.binary ? '二进制' : `+${e.insertions} −${e.deletions}`;
    div.appendChild(num);

    div.addEventListener('click', () => {
      lastSelectedPath = e.path;
      lastEntry = e;
      document.querySelectorAll('.row.selected').forEach((r) => r.classList.remove('selected'));
      div.classList.add('selected');
      openDiff(e);
    });
    div.addEventListener('contextmenu', (ev) => {
      ev.preventDefault();
      lastSelectedPath = e.path;
      lastEntry = e;
      showCtxMenu(ev.clientX, ev.clientY, e.path);
    });
    return div;
  }

  function showCtxMenu(x, y, path) {
    const menu = document.getElementById('ctx-menu');
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
    menu.classList.remove('hidden');
    document.getElementById('ctx-open-folder').onclick = async () => {
      menu.classList.add('hidden');
      try { await send('openInExplorer', { path }); } catch (e) {}
    };
    setTimeout(() => document.addEventListener('click', function close() {
      menu.classList.add('hidden');
      document.removeEventListener('click', close);
    }), 0);
  }

  function fileExt(path) {
    const m = path.split('/').pop().split('.');
    return m.length > 1 ? m.pop().toLowerCase() : '';
  }

  function highlightLine(line, ext) {
    if (!line) return '';
    let html = esc(line);
    if (ext === 'cs' || ext === 'ts' || ext === 'js' || ext === 'tsx' || ext === 'vue') {
      html = html.replace(/(\/\/.*)$/g, '<span class="tok-com">$1</span>');
    } else if (ext === 'py') {
      html = html.replace(/(#.*)$/g, '<span class="tok-com">$1</span>');
    } else if (ext === 'css' || ext === 'scss') {
      html = html.replace(/(\/\*.*?\*\/)$/g, '<span class="tok-com">$1</span>');
    }
    html = html.replace(/(&quot;.*?&quot;|'.*?'|`.*?`)/g, '<span class="tok-str">$1</span>');
    html = html.replace(/\b(\d+\.?\d*)\b/g, '<span class="tok-num">$1</span>');
    const kw = 'const|let|var|function|return|if|else|for|while|new|class|extends|import|from|export|async|await|try|catch|throw|this|typeof|null|undefined|true|false|public|private|protected|void|int|string|bool|readonly|override|static|get|set|namespace|using|interface|type|enum|switch|case|break|continue|delete|in|of|do';
    html = html.replace(new RegExp('\\b(' + kw + ')\\b', 'g'), '<span class="tok-key">$1</span>');
    return html;
  }

  // 简单行级 LCS diff（限制规模，避免大文件卡死）
  function computeDiff(oldLines, newLines) {
    const MAX = 2000;
    if (oldLines.length > MAX || newLines.length > MAX) {
      return { ops: oldLines.map((l, i) => ({ t: 'ctx', o: l, oi: i + 1 }))
        .concat(newLines.map((l, i) => ({ t: 'add', n: l, ni: i + 1 }))), truncated: true };
    }
    const n = oldLines.length, m = newLines.length;
    // dp[i][j] = LCS length
    const dp = new Array(n + 1);
    for (let i = 0; i <= n; i++) dp[i] = new Int32Array(m + 1);
    for (let i = n - 1; i >= 0; i--) {
      for (let j = m - 1; j >= 0; j--) {
        dp[i][j] = oldLines[i] === newLines[j] ? dp[i + 1][j + 1] + 1
          : Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
    const ops = [];
    let i = 0, j = 0;
    while (i < n && j < m) {
      if (oldLines[i] === newLines[j]) { ops.push({ t: 'ctx', o: oldLines[i], oi: i + 1, n: newLines[j], ni: j + 1 }); i++; j++; }
      else if (dp[i + 1][j] >= dp[i][j + 1]) { ops.push({ t: 'del', o: oldLines[i], oi: i + 1 }); i++; }
      else { ops.push({ t: 'add', n: newLines[j], ni: j + 1 }); j++; }
    }
    while (i < n) { ops.push({ t: 'del', o: oldLines[i], oi: i + 1 }); i++; }
    while (j < m) { ops.push({ t: 'add', n: newLines[j], ni: j + 1 }); j++; }
    return { ops, truncated: false };
  }

  function esc(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function renderDiff(oldText, newText) {
    const host = document.getElementById('monaco-host');
    const oldLines = oldText.replace(/\r\n/g, '\n').split('\n');
    const newLines = newText.replace(/\r\n/g, '\n').split('\n');
    // 去掉末尾空行（split 末尾换行产生的）
    while (oldLines.length && oldLines[oldLines.length - 1] === '') oldLines.pop();
    while (newLines.length && newLines[newLines.length - 1] === '') newLines.pop();
    const { ops, truncated } = computeDiff(oldLines, newLines);

    // 折叠未改动区域：保留每段 diff 前后各 3 行上下文
    const shown = new Array(ops.length).fill(false);
    ops.forEach((op, idx) => {
      if (op.t !== 'ctx') {
        for (let k = Math.max(0, idx - 3); k <= Math.min(ops.length - 1, idx + 3); k++) shown[k] = true;
      }
    });
    // 始终显示首末
    if (ops.length) { shown[0] = true; shown[ops.length - 1] = true; }

    let html = '<table class="diff">';
    let skipped = 0;
    for (let idx = 0; idx < ops.length; idx++) {
      const op = ops[idx];
      if (!shown[idx]) { skipped++; continue; }
      if (skipped > 0) {
        html += `<tr class="skip"><td colspan="3">… ${skipped} 行未改动 …</td></tr>`;
        skipped = 0;
      }
      if (op.t === 'ctx') {
        html += `<tr class="ctx"><td class="ln">${op.oi}</td><td class="ln">${op.ni}</td><td class="code">${esc(op.o) || ' '}</td></tr>`;
      } else if (op.t === 'del') {
        html += `<tr class="del"><td class="ln">${op.oi}</td><td class="ln"></td><td class="code">- ${esc(op.o) || ' '}</td></tr>`;
      } else {
        html += `<tr class="add"><td class="ln"></td><td class="ln">${op.ni}</td><td class="code">+ ${esc(op.n) || ' '}</td></tr>`;
      }
    }
    if (skipped > 0) html += `<tr class="skip"><td colspan="3">… ${skipped} 行未改动 …</td></tr>`;
    html += '</table>';
    host.innerHTML = html;
    return truncated;
  }

  async function openDiff(entry) {
    const banner = document.getElementById('right-banner');
    const ph = document.getElementById('right-placeholder');
    const tabs = document.getElementById('right-tabs');
    ph.classList.add('hidden');
    banner.classList.add('hidden');
    tabs.classList.remove('hidden');

    let data;
    try {
      data = await send('getFileContent', { path: entry.path });
    } catch (e) { return; }

    // 更新右上角 tooltip 元信息
    renderTooltip(entry, data);

    if (rightTab === 'info') {
      document.getElementById('monaco-host').classList.add('hidden');
      document.getElementById('right-info').classList.remove('hidden');
      renderFileContent(data.newText || '');
      return;
    }
    document.getElementById('monaco-host').classList.remove('hidden');
    document.getElementById('right-info').classList.add('hidden');

    // 二进制：图片预览或占位
    if (data.binary) {
      if (data.oldImage || data.newImage) {
        const host = document.getElementById('monaco-host');
        host.innerHTML = `<div class="img-preview">
          <figure><figcaption>旧</figcaption>${data.oldImage ? `<img src="data:application/octet-stream;base64,${data.oldImage}">` : '（无）'}</figure>
          <figure><figcaption>新</figcaption>${data.newImage ? `<img src="data:application/octet-stream;base64,${data.newImage}">` : '（无）'}</figure>
        </div>`;
      } else {
        document.getElementById('monaco-host').innerHTML = '';
        ph.textContent = '二进制文件已变更（无法文本对比）';
        ph.classList.remove('hidden');
      }
      return;
    }

    const truncated = renderDiff(data.oldText || '', data.newText || '');
    if (truncated || data.truncated) {
      banner.textContent = '文件较大，已截断，仅显示部分内容';
      banner.classList.remove('hidden');
    }
  }

  // 详情 tab：显示文件当前最新内容（语法高亮，不做红绿对比）
  function renderFileContent(text) {
    const info = document.getElementById('right-info');
    const ext = lastEntry ? fileExt(lastEntry.path) : '';
    const lines = text.replace(/\r\n/g, '\n').split('\n');
    while (lines.length && lines[lines.length - 1] === '') lines.pop();
    let html = '<table class="diff plain">';
    lines.forEach((line, i) => {
      html += `<tr class="ctx"><td class="ln">${i + 1}</td><td class="code">${highlightLine(line, ext) || ' '}</td></tr>`;
    });
    html += '</table>';
    info.innerHTML = html;
    applyFindHighlight();
  }

  // 右上角 hover tooltip：文件元信息
  function renderTooltip(entry, data) {
    const tip = document.getElementById('info-tip');
    if (!tip) return;
    const statusMap = { added: '新增', modified: '修改', deleted: '删除', renamed: '重命名', unchanged: '未改动' };
    const size = data.size || 0;
    const sizeStr = size < 1024 ? size + ' B' : size < 1048576 ? (size / 1024).toFixed(1) + ' KB' : (size / 1048576).toFixed(2) + ' MB';
    const mod = data.modified ? new Date(data.modified).toLocaleString() : '';
    tip.innerHTML =
      `<div class="tip-row"><span class="tip-k">路径</span><span class="tip-v">${esc(entry.path)}</span></div>` +
      `<div class="tip-row"><span class="tip-k">状态</span><span class="tip-v">${statusMap[entry.status] || entry.status}</span></div>` +
      `<div class="tip-row"><span class="tip-k">大小</span><span class="tip-v">${sizeStr}</span></div>` +
      `<div class="tip-row"><span class="tip-k">修改时间</span><span class="tip-v">${mod}</span></div>` +
      `<div class="tip-row"><span class="tip-k">编码</span><span class="tip-v">${esc(data.encoding || '')}</span></div>` +
      `<div class="tip-row"><span class="tip-k">语言</span><span class="tip-v">${esc(data.language || '')}</span></div>` +
      `<div class="tip-row"><span class="tip-k">二进制</span><span class="tip-v">${data.binary ? '是' : '否'}</span></div>` +
      (entry.status !== 'unchanged' ? `<div class="tip-row"><span class="tip-k">增/删行</span><span class="tip-v">+${entry.insertions} −${entry.deletions}</span></div>` : '');
  }

  // ---- 数据加载 ----
  async function loadChanges() {
    if (!activeRepo) return;
    try {
      const data = await send('listChanges');
      current = data.changeSet;
      renderToolbar();
      renderList();
    } catch (e) { /* 错误条已显示 */ }
  }

  async function bootstrap() {
    const data = await send('bootstrap');
    repos = data.repos || [];
    activeRepo = data.activeRepo || '';
    inlineDiff = data.settings?.inlineDiff !== false;
    renderToolbar();
    if (activeRepo) await loadChanges();
    else renderList();

    // 首次引导（FR-11）
    if (activeRepo && data.settings?.onboardingDone === false) {
      $('onboarding').classList.remove('hidden');
    }
  }

  $('btn-onboarding-ok').addEventListener('click', async () => {
    $('onboarding').classList.add('hidden');
    try { await send('saveSettings', { onboardingDone: true }); } catch (e) {}
  });

  // ---- 事件 ----
  $('repo-select').addEventListener('change', async (e) => {
    const path = e.target.value;
    if (!path) return;
    await send('selectRepo', { path });
    activeRepo = path;
    current = null; baseline = null;
    await loadChanges();
  });

  $('btn-add-repo').addEventListener('click', async () => {
    try {
      const data = await send('addRepo');
      await bootstrap();
      toast(`已添加仓库：${data.repo.name}`);
    } catch (e) { showError({ message: e.message || '添加仓库失败' }); }
  });
  $('btn-pick-repo').addEventListener('click', () => $('btn-add-repo').click());
  $('btn-empty-refresh').addEventListener('click', loadChanges);
  $('btn-refresh').addEventListener('click', loadChanges);
  $('btn-view').addEventListener('click', async () => {
    inlineDiff = !inlineDiff;
    if (diffEditor) diffEditor.updateOptions({ renderSideBySide: !inlineDiff });
    try { await send('saveSettings', { inlineDiff }); } catch (e) {}
  });

  // FR-10 快捷键
  document.addEventListener('keydown', async (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if (e.key === 'F5') return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'r') { e.preventDefault(); loadChanges(); }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'i') { e.preventDefault(); $('btn-view').click(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      const fi = document.getElementById('find-input');
      if (fi) { fi.classList.remove('hidden'); fi.focus(); }
    }
  });

  $('search').addEventListener('input', (e) => { searchQ = e.target.value; renderList(); });
  document.querySelectorAll('#filter .f[data-f]').forEach((b) => {
    b.addEventListener('click', () => {
      document.querySelectorAll('#filter .f').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      filter = b.dataset.f;
      renderList();
    });
  });
  $('btn-view-mode').addEventListener('click', () => {
    viewMode = viewMode === 'tree' ? 'flat' : 'tree';
    $('btn-view-mode').textContent = viewMode === 'tree' ? '平铺' : '树';
    renderList();
  });
  $('btn-scope').addEventListener('click', async () => {
    showAllFiles = !showAllFiles;
    $('btn-scope').textContent = showAllFiles ? '改动' : '全部';
    if (showAllFiles && allFiles.length === 0) {
      try { const d = await send('listAllFiles'); allFiles = d.files || []; } catch (e) {}
    }
    renderList();
  });
  document.querySelectorAll('#right-tabs .rtab').forEach((b) => {
    b.addEventListener('click', () => {
      document.querySelectorAll('#right-tabs .rtab').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      rightTab = b.dataset.tab;
      if (lastEntry) openDiff(lastEntry);
    });
  });
  const infoIcon = document.getElementById('info-icon');
  const infoTip = document.getElementById('info-tip');
  if (infoIcon && infoTip) {
    infoIcon.addEventListener('mouseenter', () => infoTip.classList.remove('hidden'));
    infoIcon.addEventListener('mouseleave', () => infoTip.classList.add('hidden'));
  }

  // ---- 查找栏 ----
  let findMatches = [];
  let findIdx = 0;
  const findInput = document.getElementById('find-input');
  const findCount = document.getElementById('find-count');

  function applyFindHighlight() {
    if (!findInput) return;
    const q = findInput.value.trim();
    findMatches = [];
    findIdx = 0;
    if (!q) { findCount.textContent = ''; return; }
    // 在可见的 code 单元格里高亮
    const host = document.getElementById('right-info');
    const cells = host.querySelectorAll('td.code');
    let n = 0;
    cells.forEach((cell) => {
      const orig = cell.getAttribute('data-orig') || cell.innerHTML;
      cell.setAttribute('data-orig', orig);
      const re = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
      cell.innerHTML = orig.replace(re, '<span class="tok-find">$1</span>');
      const count = (orig.match(re) || []).length;
      n += count;
    });
    findCount.textContent = n ? `1/${n}` : '0/0';
    findMatches = host.querySelectorAll('.tok-find');
    if (findMatches.length) findMatches[0].classList.add('current');
  }

  function findNext(dir) {
    if (!findMatches.length) return;
    findMatches[findIdx].classList.remove('current');
    findIdx = (findIdx + dir + findMatches.length) % findMatches.length;
    findMatches[findIdx].classList.add('current');
    findCount.textContent = `${findIdx + 1}/${findMatches.length}`;
    findMatches[findIdx].scrollIntoView({ block: 'center' });
  }

  if (findInput) {
    findInput.addEventListener('input', applyFindHighlight);
    findInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); findNext(e.shiftKey ? -1 : 1); }
      if (e.key === 'Escape') { findInput.classList.add('hidden'); findInput.value = ''; applyFindHighlight(); }
    });
  }
  const findPrevBtn = document.getElementById('find-prev');
  const findNextBtn = document.getElementById('find-next');
  const findCloseBtn = document.getElementById('find-close');
  if (findPrevBtn) findPrevBtn.addEventListener('click', () => findNext(-1));
  if (findNextBtn) findNextBtn.addEventListener('click', () => findNext(1));
  if (findCloseBtn) findCloseBtn.addEventListener('click', () => { findInput.classList.add('hidden'); findInput.value = ''; applyFindHighlight(); });

  $('error-bar').addEventListener('click', (e) => e.target.classList.add('hidden'));

  bootstrap();
})();
